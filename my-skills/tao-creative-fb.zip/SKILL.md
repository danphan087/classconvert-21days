---
name: tao-creative-fb
description: "Sản xuất FULL CONTENT (cả Ảnh và Văn bản) cho Facebook. Có 2 mode: Mode 1 (Content Free - auto post) gen 3 ý tưởng -> chọn -> post tự động. Mode 2 (Creative Ads) tạo 3 bộ ảnh + copy (pain/solution/social proof) để chạy ads. Trigger Mode 1: 'tạo content cho ngày mai', 'gen bài Page', 'content free'. Trigger Mode 2: 'tạo creative ads', 'gen ads'."
---

# Skill: tao-creative-fb

## Cấp độ: Cấp 3 (Có Python scripts xử lý tự động)

## Mục đích
Tạo ra **CẢ ẢNH VÀ VĂN BẢN** hoàn chỉnh cho các bài đăng Facebook, hỗ trợ cả 2 nhu cầu: đăng nội dung hữu ích hằng ngày (Organic) và chạy quảng cáo (Ads).

## 2 Mode Hoạt Động

### MODE 1: CONTENT FREE (Auto-post Page hằng ngày)
- **Triggers:** `tạo content cho ngày mai`, `gen bài Page`, `content free`, `content organic`
- **Luồng xử lý:**
  1. **Bước A (Lên ý tưởng):** Agent tự động sinh ra 3 ý tưởng bài đăng (mỗi ý gồm tiêu đề và góc nhìn ngắn) dựa trên chủ đề yêu cầu hoặc business context (ClassConvert). Agent dừng lại và yêu cầu User chọn 1.
  2. **Bước B (Gen Content):** Sau khi User chọn (reply 1, 2, hoặc 3), Agent gọi script để:
     - Dùng OpenAI DALL-E 3 tạo ra 1 ảnh đẹp 1024x1024.
     - Dùng LLM viết 1 caption hoàn chỉnh (80-150 từ, cấu trúc Hook+Body+Soft CTA) theo đúng Brand Voice.
  3. **Bước C (Preview):** Agent hiển thị ảnh và caption cho User xem. Đợi duyệt.
  4. **Bước D (Post):** User phản hồi `OK`. Agent gọi `scripts/post_facebook.py` để đăng ảnh và caption lên Facebook Page.

### MODE 2: CREATIVE ADS (Sinh hàng loạt, không tự đăng)
- **Triggers:** `tạo creative ads`, `gen ads`, `cần creative cho chiến dịch`
- **Luồng xử lý:**
  1. Agent nhận thông tin sản phẩm (giá, USP, mục tiêu) từ câu lệnh của User.
  2. Agent tiến hành tạo **3 BỘ CREATIVE** hoàn chỉnh, mỗi bộ là 1 cặp gồm:
     - 1 Ảnh quảng cáo (1024x1024, có khoảng trống để chèn chữ nếu cần).
     - 1 Ad Copy (80-150 từ, Hook mạnh + USP + CTA rõ ràng).
  3. Yêu cầu bắt buộc: 3 bộ phải theo 3 góc nhìn (Angles) khác nhau:
     - Bộ 1: Pain point (Nỗi đau)
     - Bộ 2: Solution (Giải pháp)
     - Bộ 3: Social proof (Bằng chứng thực tế/Testimonial)
  4. Agent trả kết quả hiển thị cho User để tải về và paste vào Ads Manager. **Không tự động đăng Facebook.**

## Configuration & Testing
- Các file logic nằm trong thư mục `scripts/`.
- Templates cho prompt tạo ảnh và viết bài nằm trong thư mục `assets/`.
- Cần cung cấp `OPENAI_API_KEY`, `FB_PAGE_ID`, và `FB_PAGE_TOKEN` vào file `.env` trước khi sử dụng.
- **Test Mode:** Thiết lập biến `DRY_RUN=true` trong file `.env` để chạy thử toàn bộ luồng mà không đăng thực sự lên Facebook.
