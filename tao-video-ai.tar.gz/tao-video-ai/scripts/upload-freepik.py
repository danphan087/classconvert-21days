import os
import time
import argparse
import requests
import json
from dotenv import load_dotenv

# Tải biến môi trường
load_dotenv()
API_KEY = os.getenv("FREEPIK_API_KEY")

def generate_video(prompt, start_image_url=None, aspect_ratio="9:16", duration="5", cfg_scale=0.5):
    if not API_KEY:
        raise ValueError("Lỗi: Không tìm thấy FREEPIK_API_KEY trong biến môi trường.")

    url = "https://api.magnific.com/v1/ai/video/kling-v3-std"
    headers = {
        "Content-Type": "application/json",
        "x-magnific-api-key": API_KEY
    }
    
    # Payload chuẩn theo API Kling 3.0
    payload = {
        "prompt": prompt,
        "generate_audio": False, # Thường video AI không cần audio native, ghép sau bằng Capcut tốt hơn
        "aspect_ratio": aspect_ratio,
        "duration": str(duration),
        "negative_prompt": "blur, distort, low quality, morphed, extra limbs, bad anatomy, bad text",
        "cfg_scale": cfg_scale
    }
    
    if start_image_url:
        payload["start_image_url"] = start_image_url

    print(f"🚀 Đang gửi yêu cầu tạo video lên Magnific/Freepik (Kling 3 Std)...")
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code != 200:
        print(f"❌ Lỗi API: {response.status_code} - {response.text}")
        return None
        
    data = response.json()
    task_id = data.get("task_id")
    if not task_id:
        # Tùy thuộc vào response thực tế của Magnific, có thể nó nằm ở cấu trúc khác. 
        # Ví dụ: response trả về {"id": "..."} thay vì {"task_id": "..."}
        # Nếu data trả về trực tiếp task_id:
        task_id = data.get("id", data.get("task_id"))
        
    print(f"✅ Đã tạo Task thành công. Task ID: {task_id}")
    return task_id

def check_task_status(task_id):
    url = f"https://api.magnific.com/v1/ai/video/kling-v3/{task_id}"
    headers = {
        "x-magnific-api-key": API_KEY
    }
    
    while True:
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            print(f"❌ Lỗi kiểm tra trạng thái: {response.status_code} - {response.text}")
            return None
            
        result = response.json()
        # Theo tài liệu: { "data": { "status": "COMPLETED", "generated": [...] } }
        data_obj = result.get("data", {})
        status = data_obj.get("status")
        
        if status == "COMPLETED":
            video_urls = data_obj.get("generated", [])
            print(f"\n🎉 Hoàn thành! Video URL: {video_urls[0]}")
            return video_urls[0]
        elif status in ["FAILED", "ERROR"]:
            print(f"\n❌ Task thất bại. Chi tiết: {result}")
            return None
        else:
            print(f"⏳ Đang xử lý... (Status: {status}). Chờ 10 giây...")
            time.sleep(10)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Upload prompt/image to Magnific/Freepik Kling 3 API")
    parser.add_argument("--prompt", type=str, required=True, help="Prompt cho video")
    parser.add_argument("--image", type=str, required=False, help="URL ảnh đầu vào (Image-to-Video)")
    parser.add_argument("--ratio", type=str, default="9:16", help="Tỉ lệ khung hình (16:9, 9:16, 1:1)")
    parser.add_argument("--duration", type=str, default="5", help="Thời lượng (3 đến 15)")
    
    args = parser.parse_args()
    
    task_id = generate_video(
        prompt=args.prompt, 
        start_image_url=args.image, 
        aspect_ratio=args.ratio,
        duration=args.duration
    )
    
    if task_id:
        check_task_status(task_id)
