# Quy Trình Sản Xuất Video AI (Skill: tao-video-ai)
Dùng cho nền tảng: Freepik / Magnific (Seedream 4.5 sinh ảnh + Kling 3.0 làm video)

## Giới thiệu
Đây là quy trình tự động hóa sản xuất video ngắn (15-25s) cho ClassConvert.
Luồng hoạt động: Sinh Kịch bản -> Sinh Ảnh tĩnh (Seedream 4.5 / Freepik Mystic) -> Tạo Video chuyển động (Kling 3.0) qua API -> Gửi Telegram -> Đăng bài.

## Quy Trình 7 Bước Thực Thi (Dành cho Agent)

### BƯỚC 1: Lên ý tưởng & Kịch bản (Storyboard)
- Đọc ngữ cảnh trong `my-business.md` (Sản phẩm ClassConvert).
- Xác định 1 Topic phù hợp (VD: Xây phễu tuyển sinh, Tự động hóa lớp học, Thoát khỏi làm thủ công).
- Phân tách thành 3-5 scene (cảnh), mỗi cảnh 4-5s.

### BƯỚC 2: Sinh Prompt cho Ảnh (Seedream / Mystic)
- Gọi script `scripts/gen-prompt.py` hoặc sử dụng LLM của chính Agent để dịch kịch bản thành Prompt Tiếng Anh chuẩn tả thực.
- Tham khảo `assets/brand-style.md` để đảm bảo tone màu chuyên nghiệp (luxury minimal, tech, B2B).
- *Tạm thời trong skill này, nếu không gọi API tạo ảnh, Agent có thể bỏ qua bước sinh ảnh và dùng Text-to-Video trực tiếp ở Bước 3.*

### BƯỚC 3: Gọi API Freepik / Magnific Kling 3.0
- Sử dụng script `scripts/upload-freepik.py` để đẩy lệnh lên API.
- Lệnh Terminal mẫu: 
  `python scripts/upload-freepik.py --prompt "A slow gentle orbit shot of a professional teacher working on a laptop, warm sunlight, cinematic" --ratio "9:16" --duration "5"`
- Nếu có ảnh đầu vào (Image-to-Video), truyền thêm tham số `--image "URL_ANH"`.
- Chờ script chạy và trả về URL file MP4 cuối cùng.

### BƯỚC 4: Gửi Preview qua Telegram
- Báo cáo cho user: "Anh ơi, em làm xong video rồi, anh xem thử nhé!" kèm theo Link MP4.
- Chờ User phản hồi "OK" hoặc yêu cầu sửa đổi.

### BƯỚC 5: Đăng Bài (Tích hợp tao-creative-fb)
- Khi User duyệt, lấy nội dung bài đăng (Caption) đã chuẩn bị ở Bước 1.
- Gửi lệnh lên Facebook Page, Reels, hoặc TikTok (Tuỳ thuộc vào cấu hình auto-post của hệ thống).
